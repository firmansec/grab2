from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import requests
import os
import random

linux = "clear"
windows = "cls"
os.system([linux, windows][os.name == "nt"])

def user_agent():
	ua = open('user-agents.txt','r').read().splitlines()
	return random.choice(ua)

def agent():
	agents = {'User-Agent':user_agent()}
	return agents

pages = 0

def grab_domain_wannazid(date):
	while True:
		global pages
		pages += 1
		url = f"https://www.uidomains.com/browse-daily-domains-difference/{pages}/{date}"
		req = requests.get(url, headers=agent(), timeout=3).text
		if 'nextPageDomains' in req:
			bs = BeautifulSoup(req,'html.parser')
			finds = bs.find('ul',class_='domains-tag-page')
			find_all_domain = finds.find_all('li')
			for done in find_all_domain:
				get_txt = (done.get_text())
				name_file = date+'.txt'
				with open(name_file,'a') as saving:
					saving.write(get_txt+'\n')
				print(f'~# {get_txt} > Page {pages}')
		else:
			print('~#> Page End')
			break

page = 0
		
def grab_domain_today_wannazid():
	while True:
		global page
		page += 1
		url = f"https://www.uidomains.com/browse-daily-domains-difference/{page}"
		req = requests.get(url, headers=agent(), timeout=3).text
		if 'nextPageDomains' in req:
			bs = BeautifulSoup(req,'html.parser')
			finds = bs.find('ul',class_='domains-tag-page')
			find_all_domain = finds.find_all('li')
			for done in find_all_domain:
				get_txt = (done.get_text())
				dt = datetime.now()
				date_str = dt.strftime('%Y-%m-%d')
				name_file = 'Today('+date_str+').txt'
				with open(name_file,'a') as saving:
					saving.write(get_txt+'\n')
				print(f'~# {get_txt} > Page {page}')
		else:
			print('~#> Page End')
			break

if __name__ == '__main__':
	banner = '''
=================================
> Grabber Domain By Date & Today
> example : (2022-11-04)
=================================
~# Feature
> Thread 
> Save file name date input
=================================
> by : wannazid
> github : github.com/wannazid
=================================
'''
	print(banner)
	menu = '''
1. Grab domain by date (2022-11-04)
2. Grab domain today
'''
	print(menu)
	choose_no = input('~#> Pilih no (1,2) : ')
	if choose_no == '1':
		date_input = input('~#> Date (yyyy-mm-dd) : ')
		thread_input = input('~#> Thread (1-100) : ')
		with ThreadPoolExecutor(max_workers=int(thread_input)) as wan:
			[wan.submit(grab_domain_wannazid, date_input)]
	elif choose_no == '2':
		dt = datetime.now()
		date_str = dt.strftime('%Y-%m-%d')
		menu = f'''
===============================
> Grab domain today
> sekarang tanggal : {date_str}
===============================
> by : wannazid
> github : github.com/wannazid
===============================		
'''		
		
		print(menu)
		thread = input('~#> Thread (1-50) : ')
		enter_continue = input('~#> Enter to continue grab domain today : ')
		with ThreadPoolExecutor(max_workers=int(thread)) as t:
			[t.submit(grab_domain_today_wannazid)]
	else:
		print('~#> Not found your choose')
		exit()