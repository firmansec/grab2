# -*- coding: utf-8 -*-
# Author imamwawe
import re
import sys, os
import requests
from datetime import datetime, timedelta
requests.urllib3.disable_warnings()
def clear():
    if sys.platform.startswith('linux'):
        os.system('clear')
    elif sys.platform.startswith('freebsd'):
        os.system('clear')
    else:
        os.system('cls')

class Grab:
	def __init__(self):
		self.all = 0
		self.black  = '\33[30m'
		self.red    = '\33[31m'
		self.green  = '\33[32m'
		self.yellow = '\33[33m'
		self.blue   = '\33[34m'
		self.VIOLET = '\33[35m'
		self.BEIGE  = '\33[36m'
		self.white  = '\33[37m'
		self.banner = f"""{self.red}××××××××××××××××××××××××××××××××
{self.yellow}.  Priv8 Domain Grabbing      
{self.yellow}.  Copyright @AXVDIGITAL        
{self.yellow}.  https://axvdigital.my.id     
{self.red}××××××××××××××××××××××××××××××××
\n{self.white}- Tool Information :
{self.BEIGE}❖ Tool Name : Domain Grabber by Date
❖ Description : Suport Old Date( depending on the domain )
{self.yellow}❖ Domains Takes : | AI | BIZ | CC | CN | COM | CX | DO | GG | HK | INFO | IO | IS | LY | ME | NET | ORG | SH | TV | US | VC |
{self.BEIGE}❖ Creator : AXVDIGITAL
❖ Version : 19.0
❖ Format : tanggal-bulan-tahun, Ex: 30-01-2006\n\n{self.white}"""
		
	def api(self, date, month, year, ext, save):
		try:
			url = f"https://data.namedog.com/Dropped/{ext}/{year}/{month}-{date}-{year}-{ext}.php"
			api = requests.get(url, headers={"user-agent":"Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36"}, stream=True, verify=False, timeout=30).text
			regex = re.findall("\r\n(.*?)\r\n", api)
			with open(f"{save}", "a+") as output:
				for results in regex:
					self.all += 1
					output.write(f"{results}\n")
			isGet = len(regex) > 0
			statusStr = self.green + "[✓]" if isGet else self.red + "[X]"
			print (f"\r{statusStr} {self.white}{ext} {date}-{month}-{year} \n{self.VIOLET}================\n{self.yellow}Total: {self.white}{self.all}", end="")
		except Exception as e:print (e)

	def daterange(self, start_date, end_date):
		for n in range(int((end_date - start_date).days)+1):
			yield start_date + timedelta(n)

	def main(self):
		try:
			dot = ["AI","BIZ","CC","CN","COM","CX","DO","GG","HK","INFO","IO","IS","LY","ME","NET","ORG","SH","TV","US","VC"]
			date1 = datetime.strptime(input("[#] From Date : "), '%d-%m-%Y')
			date2 = datetime.strptime(input("[#] To Date   : "), '%d-%m-%Y')
			if date1 > date2:
				print('[!] Format tanggal akhir harus lebih besar dari yang pertama.')
				self.main()
				return
			save = input("[#] Save      : ")
			div_date = date2 - date1
			for this_date in self.daterange(date1, date2):
				day = str(this_date.day).zfill(2)
				month = str(this_date.month).zfill(2)
				year = this_date.year
				for ext in dot:
					self.api(day, month, year, ext, save)
				#---
			#---
		except ValueError:
			print('[!] Format tanggal salah.')
			self.main()
		except KeyboardInterrupt:
			print('\n\n[:D] Goodbye!\n')

if __name__=="__main__":
	wawe = input("[+] Password : ")
	clear()
	if "a" in wawe:
		grab = Grab()
		print(grab.banner)
		grab.main()
